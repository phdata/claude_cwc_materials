# Catalyst ticket triage service

Fictional demo client. Python 3.9+, Anthropic SDK, pydantic. Artifact chain: `intent/` → `spec.md` → `plan.md` → code → `evals/results/` → PR.

## Commands
- Setup: `python3 -m venv .venv && .venv/bin/pip install -r requirements.txt`
- Test: `make test` (healthy: `NN passed`, zero failures; no network, no API key needed)
- Lint: `make lint` (healthy: no output)
- Eval: `make eval` (calls the Claude API; needs credentials; ~$3–8) · `make eval-slice SLICE=injection` (about 15 s, about $0.20)

## Conventions
- The taxonomy lives in `.claude/skills/support-taxonomy/SKILL.md`; `app/triage/taxonomy.py` mirrors it and `test_taxonomy_sync.py` enforces the match. Change the skill first.
- The model never names a queue. Routing is `route.py` only.
- Prompts are versioned in `prompt.py` (`v1`, `v2`, …). Never edit a released version; add a new one.
- Eval data is synthetic. Never paste real customer text anywhere in this repo.

## Architecture
- `app/triage/`: redact → classify (Claude) → route. `app/tests/`: unit tests.
- `evals/`: dataset, graders, runner, judge calibration, results.

## Things Claude gets wrong
- Do not "fix" a failing eval case by editing `evals/dataset/`. Fix the prompt or code; gold labels change only with the Care ops owner's sign-off.
- Don't use `budget_tokens` or `thinking: disabled` with claude-sonnet-5-5; set `output_config.effort` instead.
- Summaries must describe the request, not quote it (SEC-11 rule 6).

## Verifying your work
Run `make test` and `make lint` before reporting any task complete, and paste the output.
If a test fails, fix the code, not the test.
