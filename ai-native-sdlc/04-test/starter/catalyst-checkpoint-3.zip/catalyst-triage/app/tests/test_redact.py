from app.triage.redact import redact


def test_email():
    assert redact("reach me at jo.ortiz+ch@example.com please") == "reach me at [EMAIL] please"


def test_phone_formats():
    for p in ["(503) 555-0147", "503-555-0147", "503.555.0147", "+1 503 555 0147"]:
        assert "[PHONE]" in redact(f"call {p} today"), p


def test_card_with_spaces_and_dashes():
    assert redact("card 4111 1111 1111 1111 was charged") == "card [CARD] was charged"
    assert redact("card 4111-1111-1111-1111") == "card [CARD]"


def test_address_and_postcode():
    out = redact("Ship to 1420 Cedar Ridge Rd, Apt 4B, Bend OR 97701")
    assert "1420" not in out and "Cedar Ridge" not in out and "97701" not in out


def test_canadian_postcode():
    assert "[POSTCODE]" in redact("Montréal H2X 1Y4")


def test_order_number_is_not_pii():
    assert redact("order CH-2291047 is late") == "order CH-2291047 is late"
