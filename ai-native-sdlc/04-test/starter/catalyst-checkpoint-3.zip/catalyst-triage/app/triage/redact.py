"""PII redaction before egress (PRV-04 rule 1; address patterns added per spec concern C2)."""
import re
from typing import List, Tuple

_PATTERNS: List[Tuple[str, re.Pattern]] = [
    ("[EMAIL]", re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")),
    ("[CARD]", re.compile(r"\b(?:\d[ -]?){13,16}\d\b")),
    ("[DOB]", re.compile(r"\b(?:0?[1-9]|1[0-2])/(?:0?[1-9]|[12]\d|3[01])/(?:19|20)\d{2}\b")),
    ("[PHONE]", re.compile(r"(?:\+?1[ .-]?)?\(?\b\d{3}\)?[ .-]?\d{3}[ .-]?\d{4}\b")),
    ("[ADDRESS]", re.compile(
        r"\b\d{1,6}\s+(?:[A-Z][a-z]+\.?\s){1,4}(?:St|Street|Ave|Avenue|Rd|Road|Blvd|Boulevard|Ln|Lane|Dr|Drive|Way|Ct|Court|Pl|Place|Terrace|Hwy|rue|chemin)\b\.?(?:,?\s*(?:Apt|Unit|Suite|#)\s*\w+)?",
        re.IGNORECASE)),
    ("[POSTCODE]", re.compile(r"\b[A-Z]\d[A-Z][ -]?\d[A-Z]\d\b|\b\d{5}(?:-\d{4})?\b(?=\s*(?:$|[,.\n]|USA|US\b))")),
]


def redact(text: str) -> str:
    """Replace PII with typed placeholders. Order matters: cards before phones."""
    for placeholder, pattern in _PATTERNS:
        text = pattern.sub(placeholder, text)
    return text
