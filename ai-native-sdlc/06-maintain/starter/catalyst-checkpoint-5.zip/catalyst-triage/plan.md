# Plan: automatic ticket triage (from intent 0001 and spec.md, 2026-10-08)

Stage: 3 Build · Produced in Claude Code plan mode (read-only) · Owner: S. Patel (engineer) · Gate: engineer accepts; tech lead accepts because the change is higher-risk

## Files that change
- `app/triage/taxonomy.py` (new): categories, queues and priorities from support-taxonomy v3.1
- `app/triage/redact.py` (new): PII → typed placeholders (PRV-04 rule 1, with address patterns added per C2)
- `app/triage/schema.py` (new): pydantic `TriageResult` plus the JSON schema used for structured outputs
- `app/triage/prompt.py` (new): versioned system prompts (`v1` baseline, `v2` full rubric + injection guidance)
- `app/triage/route.py` (new): deterministic queue table and safety override (R6, R7)
- `app/triage/classify.py` (new): the Claude call, failure handling, latency and cost capture
- `app/tests/test_*.py` (new): unit tests for redaction, routing, schema and taxonomy sync. None of these call the API.
- `Makefile`, `CLAUDE.md`, `.claude/settings.json`, `.claude/hooks/*`, `.claude/agents/verifier.md`

## Order of work
1. Taxonomy constants, plus a test that fails if they drift from `.claude/skills/support-taxonomy/SKILL.md`.
2. Redaction, with tests for each PII type: email, phone, card with spaces and dashes, address, postal code.
3. Schema and routing, with tests for the safety override and the escalation routing rule.
4. Prompts v1 and v2, then `classify.py`.
5. Stage 4 eval harness (separate commit, see `evals/`).

## Risks
- **Riskiest step:** the safety override (R7). A missed keyword means a safety report waits in a normal queue. To mitigate it, the keyword list comes from the taxonomy skill, it has unit tests, and the eval has an escalation slice.
- **Redaction misses** on unusual address formats (C2 residual risk). The PII-leak grader is the backstop.
- **Prompt changes can silently regress accuracy.** Every change to `prompt.py`, `CLAUDE.md` or `.claude/**` triggers the eval workflow, and the merge is gated on thresholds.
- **Options not chosen:**
  - Fine-tuned classifier: needs labelled history we don't have.
  - Letting the model pick the queue: violates SEC-11 rule 3.
  - Regex-only triage: fails on multi-issue and French tickets.

## Proof
- `make test` passes. It covers redaction for every PII type, routing for all 9 categories, the safety override, and taxonomy/skill sync.
- `make eval` meets every ship threshold in spec.md §4 for prompt **v2**, and the results are committed under `evals/results/`.

## Gate decision
Plan accepted by S. Patel (engineer) and K. Duarte (tech lead, because of the higher-risk class) on 2026-10-08. Claude implements from this plan. *(Demo approval by fictional personas.)*
