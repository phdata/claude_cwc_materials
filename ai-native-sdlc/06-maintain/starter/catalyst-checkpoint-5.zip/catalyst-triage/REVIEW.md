# Review instructions

Stage: 5 Deploy · Owner: K. Duarte (tech lead) · Applied to every PR by Claude; a code owner still approves.

## Passes
Run three passes and tag each finding with its pass:
- **Bugs**: logic errors, broken edge cases, subtle regressions (especially routing and the safety override).
- **Security**: prompt-injection exposure (SEC-11), PII reaching the model, logs or summaries (PRV-04), secrets in code.
- **Compliance**: the change matches spec.md (R1–R10, thresholds) and plan.md; taxonomy changes start in the skill.

## What Important means here
Reserve Important for findings that would mis-route a safety or P1 ticket, leak PII, let ticket text steer the
classifier, or change eval gold labels or thresholds without owner sign-off. Style and naming are nits.

## Eval evidence
Any PR touching `app/triage/prompt.py`, `.claude/skills/**` or `CLAUDE.md` must link a passing Agent evals run.
Flag as Important if it doesn't, or if any ship threshold regressed versus the last nightly run.

## Cap the nits
Report at most five nits per review; summarize the rest as a count.

## Do not report
Anything under `evals/results/` (generated), and anything `make lint` already enforces.
