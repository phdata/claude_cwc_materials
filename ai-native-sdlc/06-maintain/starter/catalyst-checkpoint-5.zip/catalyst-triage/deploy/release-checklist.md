# Release checklist: triage v1 (shadow mode)

Stage: 5 Deploy · Prepared by: Claude (agent) · Authorized by: J. Whitfield (release manager) · Gate: production-gate hook + environment approval

> The agent prepares everything up to the production gate and cannot pass it.

| # | Check | Evidence | Status |
|---|---|---|---|
| 1 | PR reviewed by Claude against REVIEW.md, with no open Important findings | PR thread (Bugs / Security / Compliance passes) | ☐ |
| 2 | Code owner approval through branch protection | PR approvals | ☐ |
| 3 | `make test` and `make lint` green | CI check run | ☐ |
| 4 | Agent evals: candidate prompt meets **every** spec.md ship threshold | `evals/results/<latest>/results.json` | ☐ |
| 5 | Judge calibration trusted (within-1 ≥ 0.9 and pass/fail agreement ≥ 0.9) | Calibration section of the eval review | ☐ |
| 6 | Deployed to staging in **shadow mode** (suggest only; agents confirm), per spec C3 | `deploy-staging` job | ☐ |
| 7 | Rollback rehearsed in staging this week (`deploy/rollback.sh staging`) | Pipeline log | ☐ |
| 8 | Control band configured for `agent_override_rate` (`ops/bands.yaml`) | Config in main | ☐ |
| 9 | Release authorization recorded (CHG ticket) and set as `RELEASE_APPROVAL` | Change record | ☐ |

**Autonomy tiers:** dev: the agent deploys freely · staging: the agent deploys, a human is notified · production: the agent prepares and the release manager authorizes.
**Exit from shadow mode** (auto-route without confirmation) is a separate change. It needs ≥ 90% agent agreement over 14 days of shadow traffic plus the product owner's sign-off.
