#!/bin/bash
# Deploy stub for the demo. Real deploys go through the platform's MCP deploy tool, scoped per environment.
# Production is gated twice: the GitHub environment approval and the production-gate hook for agent sessions.
set -euo pipefail
env="${1:?usage: deploy.sh <staging|production> [--shadow]}"
mode="${2:-}"
echo "Deploying triage service to ${env} ${mode} (demo stub)"
