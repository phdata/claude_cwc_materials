#!/bin/bash
# The most rehearsed path in the pipeline: one command, exercised weekly in staging (playbook Stage 5).
# Rollback = switch the helpdesk integration back to manual triage (feature flag) and pin the previous release.
set -euo pipefail
env="${1:?usage: rollback.sh <staging|production>}"
echo "Rolling back triage in ${env}: flag triage.auto_classify=off, pin previous release (demo stub)"
