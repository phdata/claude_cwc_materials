"""Support taxonomy v3.1, mirrored from .claude/skills/support-taxonomy/SKILL.md.

The skill is the source of truth; app/tests/test_taxonomy_sync.py fails if this file drifts from it.
"""
TAXONOMY_VERSION = "3.1.0"

CATEGORY_QUEUE = {
    "order_status": "fulfillment",
    "shipping_problem": "fulfillment",
    "return_refund": "returns",
    "product_defect": "warranty",
    "product_safety": "safety",
    "billing_payment": "billing",
    "account_privacy": "account",
    "product_question": "sales",
    "other": "general",
}
CATEGORIES = list(CATEGORY_QUEUE)
PRIORITIES = ["P1", "P2", "P3", "P4"]
ESCALATION_REASONS = ["safety", "legal_or_chargeback", "privacy_request", "abusive", "low_confidence", "none"]
LANGUAGES = ["en", "fr", "es", "other"]
ESCALATION_QUEUE = "escalations"

# Deterministic safety override (spec R7, SEC-11 rule 4). Word-boundary regexes on redacted text.
SAFETY_PATTERNS = [
    r"\binjur\w*", r"\bburn(?:ed|t|s|ing)?\b", r"\bcaught fire\b", r"\bon fire\b", r"\bflames?\b",
    r"\bsmok(?:e|ing)\b", r"\bexplod\w*", r"\bgas leak\w*", r"\bsmell(?:s|ed)? (?:of|like) gas\b",
    r"\bcarbon monoxide\b", r"\bCO alarm\b", r"\ballergic reaction\b", r"\bhospital\w*", r"\bemergency room\b",
    r"\bbrûl\w*", r"\bincendie\b", r"\bfumée\b", r"\bbless[ée]\w*", r"\bmonoxyde\b",
]
