"""Ticket triage: redact -> classify (Claude) -> override -> route.

One Messages API call per ticket with structured outputs (spec.md §2). Failures never drop a ticket: they route to
`escalations` with escalation_reason=low_confidence.
"""
import json
import time
from dataclasses import dataclass, field
from typing import Optional

import anthropic
from pydantic import ValidationError

from .prompt import PROMPTS, user_message
from .redact import redact
from .route import apply_overrides, route, safety_hit
from .schema import OUTPUT_SCHEMA, TriageResult

MODEL = "claude-sonnet-5-5"
EFFORT = "low"
# $ per million tokens (input, output), from the Claude API pricing table, cached 2026-10-06.
PRICING = {"claude-sonnet-5-5": (2.00, 10.00), "claude-opus-5-5": (4.00, 20.00), "claude-haiku-5-5": (0.10, 0.50)}


@dataclass
class TriageOutcome:
    result: Optional[TriageResult]
    queue: str
    redacted_text: str
    raw_output: Optional[str]
    error: Optional[str]
    latency_s: float
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0
    safety_override: Optional[str] = None
    stop_reason: Optional[str] = None
    model_served: Optional[str] = None
    extra: dict = field(default_factory=dict)


def cost(model: str, input_tokens: int, output_tokens: int) -> float:
    inp, out = PRICING[model]
    return (input_tokens * inp + output_tokens * out) / 1_000_000


def _fallback(redacted_text: str, error: str, latency: float, raw: Optional[str] = None, **kw) -> TriageOutcome:
    return TriageOutcome(result=None, queue="escalations", redacted_text=redacted_text, raw_output=raw,
                         error=error, latency_s=latency, **kw)


def triage(ticket_text: str, prompt_version: str = "v2", client: Optional[anthropic.Anthropic] = None,
           model: str = MODEL, effort: str = EFFORT) -> TriageOutcome:
    client = client or anthropic.Anthropic()
    redacted_text = redact(ticket_text)
    started = time.perf_counter()
    try:
        response = client.beta.messages.create(
            model=model,
            max_tokens=2048,
            system=PROMPTS[prompt_version],
            messages=[{"role": "user", "content": user_message(redacted_text)}],
            output_config={"effort": effort, "format": {"type": "json_schema", "schema": OUTPUT_SCHEMA}},
            betas=["server-side-fallback-2026-07-01"],
            fallbacks="default",
        )
    except anthropic.RateLimitError:
        raise  # let the caller back off; the SDK has already retried
    except anthropic.APIStatusError as exc:
        return _fallback(redacted_text, f"api_error:{exc.status_code}", time.perf_counter() - started)
    except anthropic.APIConnectionError:
        return _fallback(redacted_text, "connection_error", time.perf_counter() - started)
    latency = time.perf_counter() - started

    usage = response.usage
    raw = next((b.text for b in response.content if b.type == "text"), None)
    return finalize(redacted_text, raw, latency, response.stop_reason,
                    input_tokens=usage.input_tokens, output_tokens=usage.output_tokens,
                    cost_usd=cost(model, usage.input_tokens, usage.output_tokens), model_served=response.model)


def finalize(redacted_text: str, raw: Optional[str], latency: float, stop_reason: Optional[str], **meta) -> TriageOutcome:
    """Shared post-processing for any transport: refusal check, schema validation, safety override, routing."""
    meta["stop_reason"] = stop_reason
    if stop_reason == "refusal":
        return _fallback(redacted_text, "refusal", latency, **meta)
    try:
        result = TriageResult.model_validate(json.loads(raw or ""))
    except (json.JSONDecodeError, ValidationError) as exc:
        return _fallback(redacted_text, f"schema_invalid:{type(exc).__name__}", latency, raw=raw, **meta)

    hit = safety_hit(redacted_text)
    result = apply_overrides(result, redacted_text)
    return TriageOutcome(result=result, queue=route(result), redacted_text=redacted_text, raw_output=raw,
                         error=None, latency_s=latency, safety_override=hit, **meta)
