"""Output contract for the classifier (spec.md §2)."""
from typing import Literal

from pydantic import BaseModel, Field

from .taxonomy import CATEGORIES, ESCALATION_REASONS, LANGUAGES, PRIORITIES

SUMMARY_MAX = 200


class TriageResult(BaseModel):
    category: Literal[tuple(CATEGORIES)]  # type: ignore[valid-type]
    priority: Literal[tuple(PRIORITIES)]  # type: ignore[valid-type]
    needs_human: bool
    escalation_reason: Literal[tuple(ESCALATION_REASONS)]  # type: ignore[valid-type]
    language: Literal[tuple(LANGUAGES)]  # type: ignore[valid-type]
    summary: str = Field(max_length=SUMMARY_MAX)
    confidence: float = Field(ge=0.0, le=1.0)


# JSON schema sent as output_config.format (structured outputs). Length/range limits are enforced by pydantic above.
OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "category": {"type": "string", "enum": CATEGORIES},
        "priority": {"type": "string", "enum": PRIORITIES},
        "needs_human": {"type": "boolean"},
        "escalation_reason": {"type": "string", "enum": ESCALATION_REASONS},
        "language": {"type": "string", "enum": LANGUAGES},
        "summary": {"type": "string"},
        "confidence": {"type": "number"},
    },
    "required": ["category", "priority", "needs_human", "escalation_reason", "language", "summary", "confidence"],
    "additionalProperties": False,
}
