"""Deterministic routing (spec R6) and safety override (spec R7). The model never names a queue."""
import re
from typing import Optional

from .schema import TriageResult
from .taxonomy import CATEGORY_QUEUE, ESCALATION_QUEUE, SAFETY_PATTERNS


_SAFETY_RE = [re.compile(p, re.IGNORECASE) for p in SAFETY_PATTERNS]


def safety_hit(redacted_text: str) -> Optional[str]:
    """Return the first safety phrase found, or None."""
    for rx in _SAFETY_RE:
        m = rx.search(redacted_text)
        if m:
            return m.group(0)
    return None


def apply_overrides(result: TriageResult, redacted_text: str) -> TriageResult:
    """Force safety handling when a safety keyword appears, whatever the model said."""
    if safety_hit(redacted_text) and result.category != "product_safety":
        result = result.model_copy(update={"category": "product_safety"})
    if result.category == "product_safety":
        result = result.model_copy(update={"priority": "P1", "needs_human": True, "escalation_reason": "safety"})
    return result


def route(result: TriageResult) -> str:
    if result.category == "product_safety":
        return CATEGORY_QUEUE["product_safety"]
    if result.needs_human:
        return ESCALATION_QUEUE
    return CATEGORY_QUEUE[result.category]
