"""The support-taxonomy skill is the source of truth; fail if the code drifts from it."""
import pathlib
import re

from app.triage.taxonomy import CATEGORY_QUEUE, TAXONOMY_VERSION

SKILL = pathlib.Path(__file__).resolve().parents[2] / ".claude/skills/support-taxonomy/SKILL.md"


def test_category_queue_table_matches_skill():
    rows = re.findall(r"^\| (\w+) \| [^|]+ \| (\w+) \|$", SKILL.read_text(), re.MULTILINE)
    assert {k: v for k, v in rows if k != "category"} == CATEGORY_QUEUE


def test_version_matches_skill():
    assert f"version: {TAXONOMY_VERSION}" in SKILL.read_text()
