import pytest
from pydantic import ValidationError

from app.triage.schema import OUTPUT_SCHEMA, SUMMARY_MAX, TriageResult
from app.triage.taxonomy import CATEGORIES


def test_schema_enums_match_taxonomy():
    assert OUTPUT_SCHEMA["properties"]["category"]["enum"] == CATEGORIES
    assert OUTPUT_SCHEMA["additionalProperties"] is False


def test_rejects_unknown_category():
    with pytest.raises(ValidationError):
        TriageResult(category="refund", priority="P3", needs_human=False, escalation_reason="none",
                     language="en", summary="x", confidence=0.5)


def test_rejects_long_summary():
    with pytest.raises(ValidationError):
        TriageResult(category="other", priority="P4", needs_human=False, escalation_reason="none",
                     language="en", summary="x" * (SUMMARY_MAX + 1), confidence=0.5)
