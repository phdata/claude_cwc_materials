import pytest

from app.triage.route import apply_overrides, route, safety_hit
from app.triage.schema import TriageResult
from app.triage.taxonomy import CATEGORY_QUEUE


def make(**kw):
    base = dict(category="order_status", priority="P3", needs_human=False, escalation_reason="none",
                language="en", summary="Customer asks for tracking.", confidence=0.9)
    base.update(kw)
    return TriageResult(**base)


@pytest.mark.parametrize("category,queue", list(CATEGORY_QUEUE.items()))
def test_every_category_routes(category, queue):
    assert route(make(category=category)) == queue


def test_needs_human_goes_to_escalations():
    assert route(make(category="billing_payment", needs_human=True, escalation_reason="legal_or_chargeback")) == "escalations"


def test_safety_keyword_forces_safety_even_if_model_disagrees():
    r = apply_overrides(make(category="product_defect", priority="P3"), "the stove caught fire on first use")
    assert (r.category, r.priority, r.needs_human, r.escalation_reason) == ("product_safety", "P1", True, "safety")
    assert route(r) == "safety"


def test_safety_category_always_p1_human():
    r = apply_overrides(make(category="product_safety", priority="P2"), "rash after wearing the gloves")
    assert (r.priority, r.needs_human) == ("P1", True)


def test_french_safety_keyword():
    assert safety_hit("Le réchaud a pris feu et mon fils s'est brûlé la main")


def test_no_false_hit_on_burner_or_fireplace_words():
    assert safety_hit("The burner knob is loose") is None
    assert safety_hit("Is this fire pit grate compatible with model X?") is None
