# Intent: automatic triage for inbound support tickets

Author: D. Okafor (Customer Care operations, Catalyst Holdings). Status: accepted.
Stage: 1 Plan · Owner: M. Reyes (product owner, Support Platform) · Gate: product owner accepts into Stage 2 Design
Captured: 2026-10-08 in a 25-minute brainstorm with Claude; corrected by the originator before commit.

> Catalyst Holdings is a fictional outdoor-gear retailer used for this demo. All people, tickets and figures are invented.

## Problem
Every inbound ticket (email and web form, about 1,800 a day, 3x that in the November peak) lands in one shared queue.
Tier-1 agents read each one, pick a category and priority, and re-route it to the right team by hand.
Routing takes about 2.5 minutes per ticket, and roughly 1 in 6 tickets is routed to the wrong queue and bounces at least once.
Urgent tickets (a product safety problem, a duplicate charge, a threat of a chargeback or legal action) wait in the same FIFO line as "where is my order?".

## Proposed outcome
Each new ticket is classified within seconds of arrival: category, priority (P1–P4), destination queue, and whether a human must look first.
A one-line neutral summary goes on the ticket so the receiving agent does not have to re-read the thread.
Agents can override any decision with one click, and the override is recorded.

## Affected users and systems
- Tier-1 and tier-2 support agents (receiving queues), Care team leads (escalations).
- Helpdesk platform (ticket webhook in, field update out), the existing PII redaction library, the analytics warehouse (override logging).
- Customers indirectly: faster first response on urgent tickets.

## Constraints
- Customer PII (email, phone, card numbers, street addresses) must not be sent to the model and must never appear in the summary.
- Ticket text is untrusted input. Customers must not be able to steer routing or priority by writing instructions in the ticket.
- Safety-related reports (injury, fire, gas stove, carbon monoxide) always go to a human, whatever the classifier thinks.
- No auto-replies to customers in this release; triage only.
- p95 added latency under 6 seconds; run cost under $5 per 1,000 tickets.

## Success looks like
- Mis-routes fall from about 1 in 6 to under 1 in 10.
- P1 tickets reach the escalation queue in under 5 minutes, end to end.
- Zero PII in summaries; zero successful prompt-injection re-routes in the eval suite.

## Open questions
- Should French-Canadian tickets (about 6% of volume) be in scope for v1? *(carried to spec)*
- Do wholesale/dealer accounts need a separate queue? *(originator: out of scope for v1)*
- Who owns the decision to auto-route without human review once accuracy is proven? *(carried to spec)*

## Gate decision
Accepted into Stage 2 Design by M. Reyes (product owner), 2026-10-08. Recorded as this commit. *(Demo approval by a fictional persona.)*
