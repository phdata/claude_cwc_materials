# Design-pass prompt (Stage 2)

Run by: M. Reyes (product owner) in Claude, with org skills loaded. Logged here per playbook governance: the spec, the prompt that produced it, and the skill versions in force are all version-controlled.

Skill versions in force: pii-handling 1.2.0 · llm-input-safety 1.0.3 · support-taxonomy 3.1.0

```
Read the attached intent/0001-ticket-triage.md and produce a requirements and design spec
for integrating it into our existing support platform. Apply the skills available to you so
the spec conforms to our PII handling standard, our LLM untrusted-input security standard and
the Customer Care taxonomy. Document the spec fully as spec.md, ready to hand to the
engineering team, including the eval plan and ship thresholds. Describe clearly any areas of
concern, especially where you cannot satisfy contradicting policies, and name the policy owner
for each.
```

Codified as an org-level slash command `/design-from-intent` after this first manual run.
