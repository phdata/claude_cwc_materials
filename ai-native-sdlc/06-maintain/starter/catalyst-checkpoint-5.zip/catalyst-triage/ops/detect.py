"""Deterministic control-band detector (Stage 6 · Closing the loop). No model is involved in detection.

    python -m ops.detect                 # evaluate the latest day, print the decision
    python -m ops.detect --invoke        # at 2σ+ also ask Claude (read-only, no tools) to draft the next intent.md

Rules (Western Electric, upper side): R1 latest point > mean+3σ · R2 two of the last three > mean+2σ ·
R4 eight consecutive points > mean. Tier = highest band breached: 3σ propose, 2σ diagnose, 1σ log.
"""
import argparse
import csv
import datetime as dt
import json
import pathlib
import statistics
from collections import Counter
from typing import Dict, List

ROOT = pathlib.Path(__file__).resolve().parents[1]
WINDOW = 30
MIN_VOLUME = 200


def load(path: pathlib.Path) -> List[Dict]:
    lines = [l for l in path.read_text().splitlines() if l and not l.startswith("#")]
    rows = list(csv.DictReader(lines))
    return [{"date": r["date"], "n": int(r["suggestions"]), "rate": int(r["overrides"]) / int(r["suggestions"])}
            for r in rows if int(r["suggestions"]) >= MIN_VOLUME]


def evaluate(series: List[Dict], window: int = WINDOW) -> Dict:
    if len(series) < window + 3:
        return {"tier": None, "reason": "not enough history"}
    # Baseline excludes the last 8 points so a developing drift does not hide inside its own baseline.
    base = [p["rate"] for p in series[-(window + 8):-8]] if len(series) >= window + 8 else [p["rate"] for p in series[:-3]]
    mean, sd = statistics.mean(base), statistics.pstdev(base) or 1e-9
    recent = [p["rate"] for p in series[-8:]]
    z = [(r - mean) / sd for r in recent]
    rules = []
    if z[-1] > 3:
        rules.append("R1: latest point beyond 3σ")
    if sum(1 for v in z[-3:] if v > 2) >= 2:
        rules.append("R2: two of the last three beyond 2σ")
    if all(v > 0 for v in z):
        rules.append("R4: eight consecutive points above the mean")
    tier = "3sigma" if any(r.startswith("R1") for r in rules) else "2sigma" if any(r.startswith("R2") for r in rules) \
        else "1sigma" if rules else None
    return {"tier": tier, "rules": rules, "baseline_mean": round(mean, 4), "baseline_sd": round(sd, 4),
            "latest": series[-1], "recent_z": [round(v, 2) for v in z]}


ACTIONS = {None: "none", "1sigma": "log", "2sigma": "diagnose (read-only) and draft intent.md",
           "3sigma": "propose: open PR into the review gate or trigger runbook:rollback-triage"}

DIAGNOSE_PROMPT = """You are the maintenance agent for Catalyst's ticket triage service (fictional demo company).
A deterministic control band on the shadow-mode agent override rate has been breached. Diagnose the most likely
cause from the evidence, then write the finding as an intent.md in exactly this format (markdown only, no preamble):

# Intent: <short title>
Author: Claude (maintenance loop, ops/detect.py). Status: draft, awaiting triage by the service owner.
Stage: 1 Plan · Source: control-band breach <tier> on agent_override_rate · Owner: S. Patel (service owner)

## Problem
## Evidence
## Proposed outcome
## Affected users and systems
## Constraints
## Open questions

Keep it under 45 lines. Cite numbers from the evidence. Do not propose changes to eval gold labels."""


def evidence_summary(path: pathlib.Path) -> str:
    rows = list(csv.DictReader(path.read_text().splitlines()))
    pairs = Counter((r["model_category"], r["agent_category"]) for r in rows)
    langs = Counter(r["language"] for r in rows)
    texts = Counter(r["redacted_text"] for r in rows).most_common(8)
    out = [f"{len(rows)} override records, {rows[0]['date']} to {rows[-1]['date']}.",
           "Top model->agent category changes: " + "; ".join(f"{a}->{b}: {n}" for (a, b), n in pairs.most_common(6)),
           "Languages: " + ", ".join(f"{k}: {v}" for k, v in langs.items()),
           "Most frequent overridden ticket texts (redacted):"] + [f"- ({n}x) {t}" for t, n in texts]
    return "\n".join(out)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--invoke", action="store_true")
    args = ap.parse_args(argv)
    series = load(ROOT / "ops/data/override_daily.csv")
    decision = evaluate(series)
    decision["action"] = ACTIONS[decision["tier"]]
    print(json.dumps(decision, indent=1))
    if args.invoke and decision["tier"] in ("2sigma", "3sigma"):
        from evals import cli_backend
        ev = evidence_summary(ROOT / "ops/data/overrides_recent.csv")
        user = (f"Breach: {decision['tier']} ({'; '.join(decision['rules'])}). Baseline override rate "
                f"{decision['baseline_mean']:.1%} ± {decision['baseline_sd']:.1%}; latest "
                f"{decision['latest']['rate']:.1%} on {decision['latest']['date']}.\n\nEvidence:\n{ev}")
        schema = {"type": "object", "properties": {"intent_md": {"type": "string"}, "slug": {"type": "string"}},
                  "required": ["intent_md", "slug"], "additionalProperties": False}
        out, meta = cli_backend.call(DIAGNOSE_PROMPT, user, schema, "claude-opus-5-5", "medium", timeout=300)
        n = len(list((ROOT / "intent").glob("*.md"))) + 1
        slug = "".join(c if c.isalnum() or c == "-" else "-" for c in out["slug"].lower())[:50].strip("-")
        path = ROOT / "intent" / f"{n:04d}-{slug}.md"
        path.write_text(out["intent_md"].rstrip() + "\n")
        log = {"at": dt.datetime.now().isoformat(timespec="seconds"), "decision": decision, "intent": str(path.relative_to(ROOT)),
               "cost_usd": meta["cost_usd"], "model": "claude-opus-5-5"}
        (ROOT / "ops/detect-log.jsonl").open("a").write(json.dumps(log) + "\n")
        print(f"\nDraft written: {path.relative_to(ROOT)}  (cost ${meta['cost_usd']:.3f})")


if __name__ == "__main__":
    main()
