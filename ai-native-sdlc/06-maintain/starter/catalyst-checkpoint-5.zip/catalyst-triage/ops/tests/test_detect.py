import random

from ops.detect import evaluate


def series(values):
    return [{"date": f"d{i}", "n": 1000, "rate": v} for i, v in enumerate(values)]


def flat(n=40, seed=1):
    rnd = random.Random(seed)
    return [0.08 + rnd.gauss(0, 0.004) for _ in range(n)]


def test_flat_series_no_breach():
    assert evaluate(series(flat()))["tier"] is None


def test_single_spike_is_3sigma():
    assert evaluate(series(flat() + [0.2]))["tier"] == "3sigma"


def test_two_of_three_beyond_2sigma():
    v = flat()
    v[-2], v[-1], v[-3] = 0.08 + 0.004 * 2.6, 0.08 + 0.004 * 2.5, 0.08
    assert evaluate(series(v))["tier"] in ("2sigma", "3sigma")


def test_slow_drift_caught_by_run_rule():
    v = flat() + [0.0815 + 0.0002 * i for i in range(8)]
    d = evaluate(series(v))
    assert d["tier"] is not None and any(r.startswith("R4") for r in d["rules"])


def test_not_enough_history():
    assert evaluate(series(flat(10)))["tier"] is None
