"""Eval runner (Stage 4). Runs prompt versions over the gold dataset, grades every run, judges summaries,
calibrates the judge, aggregates against spec.md thresholds, and writes evals/results/<stamp>/results.json.

Exit code 1 if the candidate prompt (last in --prompts) misses any ship threshold: CI uses this as the merge gate.

    python -m evals.run_eval --prompts v1,v2 --runs 3
    python -m evals.run_eval --prompts v2 --runs 1 --slice injection --tag slice-injection
"""
import argparse
import datetime as dt
import hashlib
import json
import pathlib
import statistics
import subprocess
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor

import anthropic

from app.triage import classify
from app.triage.prompt import PROMPTS
from app.triage.taxonomy import CATEGORIES, TAXONOMY_VERSION
from evals import cli_backend, graders, judge

ROOT = pathlib.Path(__file__).resolve().parents[1]
DATASET = ROOT / "evals/dataset/tickets.jsonl"
CALIBRATION = ROOT / "evals/dataset/judge_calibration.jsonl"
THRESHOLDS = json.loads((ROOT / "evals/thresholds.json").read_text())


def sha(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()[:12]


def git_sha() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT, text=True).strip()
    except Exception:
        return "unknown"


def skill_versions():
    out = {}
    for p in sorted((ROOT / ".claude/skills").glob("*/SKILL.md")):
        for line in p.read_text().splitlines():
            if line.startswith("version:"):
                out[p.parent.name] = line.split(":", 1)[1].strip()
    return out


BACKEND = {"triage": classify.triage, "judge": judge.judge}


def with_backoff(fn, *a, **kw):
    for attempt in range(6):
        try:
            return fn(*a, **kw)
        except (anthropic.RateLimitError, cli_backend.RateLimited):
            time.sleep(min(90, 2 ** attempt * 5))
    return fn(*a, **kw)


def run_one(client, case, prompt_version, run_idx, model, effort, use_judge):
    oc = with_backoff(BACKEND["triage"], case["text"], prompt_version, client, model, effort)
    out = {
        "result": oc.result.model_dump() if oc.result else None,
        "queue": oc.queue, "error": oc.error, "raw_output": oc.raw_output,
        "latency_s": round(oc.latency_s, 3), "input_tokens": oc.input_tokens, "output_tokens": oc.output_tokens,
        "cost_usd": oc.cost_usd, "safety_override": oc.safety_override, "stop_reason": oc.stop_reason,
        "model_served": oc.model_served,
    }
    out["grades"] = graders.grade(case, out)
    if use_judge and oc.result:
        j = with_backoff(BACKEND["judge"], oc.redacted_text, oc.result.summary, client)
        out["judge"] = {"score": j["score"], "reasoning": j["reasoning"], "cost_usd": j["cost_usd"]}
    return case["id"], prompt_version, run_idx, out


def percentile(xs, p):
    if not xs:
        return None
    xs = sorted(xs)
    k = (len(xs) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


def aggregate(cases, prompt_version, partial=False):
    """partial=True for slice/case subsets: cost is not gated (a handful of cold-cache calls overstates it)."""
    runs = [(c, r) for c in cases for r in c["runs"][prompt_version]]
    n = len(runs)
    g = lambda c, r, k: r["grades"].get(k)

    def rate(key, field="pass"):
        vals = [g(c, r, key)[field] for c, r in runs if g(c, r, key) is not None]
        return sum(vals) / len(vals) if vals else None

    nh = [(g(c, r, "needs_human")["pred"], g(c, r, "needs_human")["gold"]) for c, r in runs]
    tp = sum(1 for p, gd in nh if p and gd)
    pos = sum(1 for _, gd in nh if gd)
    pred_pos = sum(1 for p, _ in nh if p)
    judged = [r["judge"]["score"] for _, r in runs if r.get("judge") and r["judge"]["score"] is not None]
    lat = [r["latency_s"] for _, r in runs if r["error"] is None]
    costs = [r["cost_usd"] for _, r in runs if r["cost_usd"]]
    inj = [g(c, r, "injection")["pass"] for c, r in runs if g(c, r, "injection") is not None]
    metrics = {
        "runs": n,
        "schema_valid_rate": rate("schema_valid"),
        "category_accuracy": rate("category"),
        "category_accuracy_strict": rate("category", "strict"),
        "queue_accuracy": rate("queue"),
        "priority_exact": rate("priority"),
        "priority_within1": rate("priority", "within1"),
        "needs_human_recall": tp / pos if pos else None,
        "needs_human_precision": tp / pred_pos if pred_pos else None,
        "pii_leaks": sum(1 for c, r in runs if g(c, r, "pii_leak") is not None and not g(c, r, "pii_leak")["pass"]),
        "injection_resistance": sum(inj) / len(inj) if inj else None,
        "judge_mean": statistics.mean(judged) if judged else None,
        "latency_p50_s": percentile(lat, 0.5),
        "latency_p95_s": percentile(lat, 0.95),
        "cost_per_1k_usd": statistics.mean(costs) * 1000 if costs else None,
    }
    gates = {}
    for key, th in THRESHOLDS.items():
        if key.startswith("_"):
            continue
        v = metrics.get(key)
        ok = None if v is None else (v >= th["value"] if th["op"] == ">=" else v <= th["value"])
        if partial and key == "cost_per_1k_usd":
            ok = None  # measured on full runs only
        gates[key] = {"value": v, "threshold": th["value"], "op": th["op"], "label": th["label"], "pass": ok}
    metrics["ship"] = all(x["pass"] is not False for x in gates.values()) and all(
        x["pass"] is not None for k, x in gates.items()
        if k not in ("judge_mean", "pii_leaks", "injection_resistance") + (("cost_per_1k_usd",) if partial else ()))

    by_slice = defaultdict(list)
    for c, r in runs:
        by_slice[c["slice"]].append((c, r))
    slices = {}
    for s, items in sorted(by_slice.items()):
        sj = [r["judge"]["score"] for _, r in items if r.get("judge") and r["judge"]["score"] is not None]
        slices[s] = {
            "runs": len(items),
            "category": sum(r["grades"]["category"]["pass"] for _, r in items) / len(items),
            "queue": sum(r["grades"]["queue"]["pass"] for _, r in items) / len(items),
            "priority_exact": sum(r["grades"]["priority"]["pass"] for _, r in items) / len(items),
            "needs_human": sum(r["grades"]["needs_human"]["pass"] for _, r in items) / len(items),
            "judge_mean": statistics.mean(sj) if sj else None,
        }

    confusion = {gold: {pred: 0 for pred in CATEGORIES + ["(error)"]} for gold in CATEGORIES}
    for c, r in runs:
        pred = r["result"]["category"] if r["result"] else "(error)"
        confusion[c["gold"]["category"]][pred] += 1

    flaky = []
    for c in cases:
        rs = c["runs"][prompt_version]
        if len(rs) < 2:
            continue
        sig = Counter((r["result"] or {}).get("category", "(error)") + "/" + (r["result"] or {}).get("priority", "-") for r in rs)
        passes = [all(v["pass"] for k, v in r["grades"].items() if k in ("category", "queue", "priority")) for r in rs]
        if len(sig) > 1 or len(set(passes)) > 1:
            flaky.append({"id": c["id"], "slice": c["slice"], "outputs": dict(sig), "pass_pattern": passes})

    return {"metrics": metrics, "gates": gates, "by_slice": slices, "confusion": confusion, "flaky": flaky}


def calibrate(client):
    rows = [json.loads(l) for l in CALIBRATION.read_text().splitlines() if l.strip()]

    def one(row):
        j = with_backoff(BACKEND["judge"], row["ticket"], row["summary"], client)
        return {**row, "judge_score": j["score"], "judge_reasoning": j["reasoning"], "cost_usd": j["cost_usd"]}

    with ThreadPoolExecutor(6) as ex:
        out = list(ex.map(one, rows))
    scored = [r for r in out if r["judge_score"] is not None]
    exact = sum(r["judge_score"] == r["label"] for r in scored) / len(scored)
    within1 = sum(abs(r["judge_score"] - r["label"]) <= 1 for r in scored) / len(scored)
    # Pass/fail split agreement: does the judge put each summary on the same side of the 4.0 bar as the label?
    side = sum((r["judge_score"] >= 4) == (r["label"] >= 4) for r in scored) / len(scored)
    return {"items": out, "exact": exact, "within1": within1, "pass_fail_agreement": side,
            "trusted": within1 >= 0.9 and side >= 0.9,
            "label_source": "Labels drafted by Claude from the rubric; confirm with a human reviewer before relying on them."}


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--prompts", default="v1,v2")
    ap.add_argument("--runs", type=int, default=3)
    ap.add_argument("--slice", default=None)
    ap.add_argument("--cases", default=None, help="comma-separated case IDs")
    ap.add_argument("--tag", default="full")
    ap.add_argument("--model", default=classify.MODEL)
    ap.add_argument("--effort", default=classify.EFFORT)
    ap.add_argument("--concurrency", type=int, default=8)
    ap.add_argument("--no-judge", action="store_true")
    ap.add_argument("--backend", choices=["auto", "api", "cli"], default="auto",
                    help="api = Anthropic SDK (needs credentials); cli = Claude Code headless (claude -p). auto: api if ANTHROPIC_API_KEY is set, else cli")
    args = ap.parse_args(argv)
    import os
    backend = args.backend if args.backend != "auto" else ("api" if os.environ.get("ANTHROPIC_API_KEY") else "cli")
    if backend == "cli":
        BACKEND.update(triage=cli_backend.triage, judge=judge.judge_cli)

    prompts = args.prompts.split(",")
    cases = [json.loads(l) for l in DATASET.read_text().splitlines() if l.strip()]
    if args.slice:
        cases = [c for c in cases if c["slice"] == args.slice]
    if args.cases:
        wanted = set(args.cases.split(","))
        cases = [c for c in cases if c["id"] in wanted]
    for c in cases:
        c["runs"] = {p: [None] * args.runs for p in prompts}

    client = anthropic.Anthropic(max_retries=4) if backend == "api" else None
    started = time.time()
    jobs = [(c, p, i) for c in cases for p in prompts for i in range(args.runs)]
    by_id = {c["id"]: c for c in cases}
    print(f"Running {len(jobs)} triage calls ({len(cases)} cases x {len(prompts)} prompts x {args.runs} runs) on {args.model} via {backend} ...", flush=True)
    done = 0
    with ThreadPoolExecutor(args.concurrency) as ex:
        futs = [ex.submit(run_one, client, c, p, i, args.model, args.effort, not args.no_judge) for c, p, i in jobs]
        for f in futs:
            cid, p, i, out = f.result()
            by_id[cid]["runs"][p][i] = out
            done += 1
            if done % 25 == 0 or done == len(jobs):
                print(f"  {done}/{len(jobs)}", flush=True)

    calibration = None if (args.no_judge or args.slice or args.cases) else calibrate(client)
    results = {
        "meta": {
            "timestamp": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
            "tag": args.tag, "git_sha": git_sha(), "duration_s": round(time.time() - started, 1),
            "backend": backend, "model": args.model, "effort": args.effort, "judge_model": judge.JUDGE_MODEL,
            "judge_effort": judge.JUDGE_EFFORT, "runs_per_case": args.runs, "prompts": prompts,
            "prompt_hashes": {p: sha(PROMPTS[p]) for p in prompts}, "dataset_sha": sha(DATASET.read_text()),
            "n_cases": len(cases), "slice_filter": args.slice, "taxonomy_version": TAXONOMY_VERSION,
            "skill_versions": skill_versions(), "sdk_version": anthropic.__version__,
        },
        "cases": cases,
        "aggregates": {p: aggregate(cases, p, partial=bool(args.slice or args.cases)) for p in prompts},
        "judge_calibration": calibration,
    }
    total = sum(r["cost_usd"] + (r.get("judge") or {}).get("cost_usd", 0)
                for c in cases for p in prompts for r in c["runs"][p])
    total += sum(i["cost_usd"] for i in (calibration or {}).get("items", []))
    results["meta"]["total_cost_usd"] = round(total, 4)

    stamp = dt.datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    out_dir = ROOT / "evals/results" / f"{stamp}-{args.tag}"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "results.json").write_text(json.dumps(results, indent=1, ensure_ascii=False))

    print(f"\nResults: {out_dir.relative_to(ROOT)}/results.json   cost ${total:.2f}   {results['meta']['duration_s']}s")
    for p in prompts:
        a = results["aggregates"][p]
        print(f"\n== prompt {p}: {'SHIP' if a['metrics']['ship'] else 'NO-SHIP'}")
        for k, gt in a["gates"].items():
            v = gt["value"]
            vs = "n/a" if v is None else (f"{v:.3f}" if isinstance(v, float) else str(v))
            mark = {True: "PASS", False: "FAIL", None: " n/a"}[gt["pass"]]
            note = "  not gated: measured on full runs only" if gt["pass"] is None and k == "cost_per_1k_usd" else ""
            print(f"  [{mark}] {gt['label']:<32} {vs:>8}  ({gt['op']} {gt['threshold']}){note}")
    if calibration:
        print(f"\nJudge calibration: exact {calibration['exact']:.2f}, within-1 {calibration['within1']:.2f}, "
              f"pass/fail agreement {calibration['pass_fail_agreement']:.2f} -> {'TRUSTED' if calibration['trusted'] else 'NOT TRUSTED'}")
    candidate = prompts[-1]
    return 0 if results["aggregates"][candidate]["metrics"]["ship"] else 1


if __name__ == "__main__":
    sys.exit(main())
