"""Eval transport through Claude Code headless mode (`claude -p`), the way the playbook runs evals in CI.

Uses the same system prompt, JSON schema, model and effort as the production SDK path in app/triage/classify.py,
and the same post-processing (finalize), so grading is identical. Runs in --safe-mode with no tools so that no
local CLAUDE.md, skills, plugins or MCP servers leak into the model's context.

Auth: whatever Claude Code is logged in with (claude.ai account or ANTHROPIC_API_KEY).
Latency: `duration_api_ms` (model API time, excludes CLI start-up). Cost: `total_cost_usd` as reported by Claude Code
at list price, which includes prompt-cache writes.
"""
import glob
import json
import os
import shutil
import subprocess
import tempfile
import time
from typing import Dict, Optional, Tuple

from app.triage.classify import TriageOutcome, _fallback, finalize
from app.triage.prompt import PROMPTS, user_message
from app.triage.redact import redact
from app.triage.schema import OUTPUT_SCHEMA

_WORKDIR = tempfile.mkdtemp(prefix="triage-eval-")  # empty cwd: nothing to auto-discover


def claude_bin() -> str:
    if os.environ.get("CLAUDE_BIN"):
        return os.environ["CLAUDE_BIN"]
    found = shutil.which("claude")
    if found:
        return found
    bundled = sorted(glob.glob(os.path.expanduser(
        "~/Library/Application Support/Claude/claude-code/*/*/claude.app/Contents/MacOS/claude")))
    if bundled:
        return bundled[-1]
    raise FileNotFoundError("claude CLI not found; set CLAUDE_BIN")


class CLIError(RuntimeError):
    pass


class RateLimited(CLIError):
    pass


def call(system: str, user: str, schema: Dict, model: str, effort: str, timeout: int = 180) -> Tuple[Optional[Dict], Dict]:
    cmd = [claude_bin(), "-p", "--safe-mode", "--disable-slash-commands", "--strict-mcp-config",
           "--exclude-dynamic-system-prompt-sections", "--tools", "", "--model", model, "--effort", effort,
           "--system-prompt", system, "--json-schema", json.dumps(schema), "--output-format", "json", user]
    started = time.perf_counter()
    proc = subprocess.run(cmd, cwd=_WORKDIR, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=timeout)
    wall = time.perf_counter() - started
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError:
        msg = (proc.stderr or proc.stdout)[-300:]
        if "rate" in msg.lower() or "429" in msg or "overloaded" in msg.lower():
            raise RateLimited(msg)
        raise CLIError(msg)
    if data.get("is_error"):
        msg = str(data.get("result") or data.get("api_error_status"))
        if "rate" in msg.lower() or "429" in msg or "limit" in msg.lower() or "overloaded" in msg.lower():
            raise RateLimited(msg)
    meta = {
        "latency_s": (data.get("duration_api_ms") or data.get("duration_ms") or wall * 1000) / 1000,
        "wall_s": wall,
        "cost_usd": data.get("total_cost_usd") or 0.0,
        "input_tokens": sum((data.get("usage") or {}).get(k, 0) for k in
                            ("input_tokens", "cache_creation_input_tokens", "cache_read_input_tokens")),
        "output_tokens": (data.get("usage") or {}).get("output_tokens", 0),
        "stop_reason": data.get("stop_reason"),
        "is_error": data.get("is_error"),
        "error_text": data.get("result") if data.get("is_error") else None,
    }
    return data.get("structured_output"), meta


def triage(ticket_text: str, prompt_version: str = "v2", client=None, model: str = "claude-sonnet-5-5",
           effort: str = "low") -> TriageOutcome:
    redacted_text = redact(ticket_text)
    try:
        out, meta = call(PROMPTS[prompt_version], user_message(redacted_text), OUTPUT_SCHEMA, model, effort)
    except subprocess.TimeoutExpired:
        return _fallback(redacted_text, "timeout", 180.0)
    except RateLimited:
        raise
    except CLIError as exc:
        return _fallback(redacted_text, f"cli_error:{str(exc)[:80]}", 0.0)
    if meta["is_error"]:
        return _fallback(redacted_text, f"cli_error:{str(meta['error_text'])[:80]}", meta["latency_s"],
                         cost_usd=meta["cost_usd"])
    stop = "refusal" if meta["stop_reason"] == "refusal" else "end_turn"
    return finalize(redacted_text, json.dumps(out) if out is not None else None, meta["latency_s"], stop,
                    input_tokens=meta["input_tokens"], output_tokens=meta["output_tokens"],
                    cost_usd=meta["cost_usd"], model_served=model)
