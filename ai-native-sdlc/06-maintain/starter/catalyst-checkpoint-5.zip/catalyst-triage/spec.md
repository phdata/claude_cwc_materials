# Spec: automatic triage for inbound support tickets

Stage: 2 Design · Source: intent/0001-ticket-triage.md · Owner: M. Reyes (product owner) · Gate: product owner accepts, tech lead consulted (higher-risk: customer data + LLM)
Produced by the design-pass prompt in `sdlc/prompts/design.md` with skills pii-handling 1.2.0, llm-input-safety 1.0.3, support-taxonomy 3.1.0.

> Fictional client (Catalyst Holdings). Demo artifact.

## 1. Requirements
| ID | Requirement | Source |
|---|---|---|
| R1 | Classify each ticket into one of 9 categories from support-taxonomy v3.1 | intent: proposed outcome |
| R2 | Assign priority P1–P4 per the taxonomy rubric | intent |
| R3 | Decide `needs_human` and give an `escalation_reason` | intent, taxonomy |
| R4 | Produce a neutral summary of at most 200 characters, in English, with no PII and no quoted instructions | intent, PRV-04 rule 3, SEC-11 rule 6 |
| R5 | Detect ticket language (`en`, `fr`, `es`, `other`) | open question (FR-CA), resolved in C1 |
| R6 | Route deterministically in code from category + needs_human; the model never names a queue | SEC-11 rule 3 |
| R7 | Product-safety keywords force `needs_human=true`, `priority=P1`, queue `safety` in code, regardless of model output | intent constraint, SEC-11 rule 4 |
| R8 | Redact PII before the model call; log only ticket ID, placeholders and outputs | PRV-04 rules 1–2 |
| R9 | p95 added latency ≤ 6 s; cost ≤ $5 per 1,000 tickets | intent constraints |
| R10 | Agent override is one click and is logged (helpdesk side; out of scope for this service) | intent |

## 2. Design
```
helpdesk webhook ──► redact.py ──► classify.py ──► route.py ──► helpdesk field update
                     (PII → [EMAIL]…)  (Claude, structured   (deterministic queue
                                        output, schema-       table + safety override)
                                        validated)
```
- **Model call.** One Messages API request per ticket, with `output_config.format` set to a JSON schema (structured outputs) and the ticket delimited in `<ticket>` tags. The system prompt is generated from support-taxonomy v3.1 so that the taxonomy has a single source of truth.
- **Model choice.** `claude-sonnet-5-5` at effort `low`. Classification is a high-volume, latency-sensitive route, which suits a low effort level, and the eval decides whether quality holds there. Server-side refusal fallbacks are set to `default`. Re-evaluate `claude-haiku-5-5` for cost after v1 ships; the eval suite makes that a measured decision.
- **Output schema:**
  - `category` (enum of 9)
  - `priority` (P1–P4)
  - `needs_human` (bool)
  - `escalation_reason` (`safety` | `legal_or_chargeback` | `privacy_request` | `abusive` | `low_confidence` | `none`)
  - `language`
  - `summary`
  - `confidence` (0–1)
- **Failure handling.** If the call errors, refuses, or produces output that fails schema validation, the ticket goes to `escalations` with `escalation_reason=low_confidence` and the error is logged. The ticket is never dropped.

## 3. Areas of concern (flagged, resolved before engineering)
| # | Concern | Policy owner | Resolution |
|---|---|---|---|
| C1 | French-Canadian tickets (about 6%): is classification in scope? | Care ops (D. Okafor) | **In scope.** Classify FR tickets; write the summary in English. A non-English eval slice is required. |
| C2 | The PII library handles email, phone and card but not street addresses, which conflicts with PRV-04 rule 1. | Privacy Office (A. Lindqvist) | Add address and postal-code redaction patterns in `redact.py`. Rule 3 stays the backstop: the PII-leak grader checks every summary against the known PII values. **Residual risk accepted** for unusual address formats and tracked in the eval suite. |
| C3 | Auto-routing with no human confirmation: who decides? | Product owner (M. Reyes) | **Shadow mode first.** The classifier suggests and agents confirm. Auto-route only after the eval ship bar is met *and* 2 weeks of shadow agreement are ≥ 90%. |
| C4 | Summaries could echo injected instructions back to agents. | AppSec (K. Duarte) | SEC-11 rule 6 goes into the prompt, and the injection eval slice also checks the summary. |

## 4. Eval plan and ship thresholds (feeds Stage 4)
- **Dataset.** At least 60 synthetic tickets with gold labels, covering these slices: `routine`, `ambiguous`, `multi_issue`, `escalation`, `non_english`, `injection`, `pii`. Each case is run 3 times to measure variance.
- **Graders.** Deterministic graders do most of the work: schema validity, category, queue, priority, needs_human, PII leak, injection resistance. An LLM judge (`claude-opus-5-5`) scores summary quality against a rubric. Before the judge's scores count toward the ship decision, it is calibrated on a labelled set.

| Metric | Ship threshold |
|---|---|
| Schema-valid outputs | 100% |
| Category accuracy | ≥ 90% |
| Queue accuracy (end to end) | ≥ 92% |
| Priority exact / within one level | ≥ 80% / ≥ 97% |
| needs_human recall (missing an escalation is the costly error) | ≥ 95% |
| PII leaks in summaries | 0 |
| Injection resistance | 100% |
| Summary judge score (1–5, mean) | ≥ 4.0 |
| p95 latency | ≤ 6 s |
| Cost per 1,000 tickets | ≤ $5 |

## 5. Out of scope
Auto-replies to customers, wholesale/dealer queue, helpdesk UI changes.

## Open questions carried forward
None blocking. C3 shadow-mode exit criteria are tracked in Stage 6 monitoring.

## Gate decision
Accepted into Stage 3 Build by M. Reyes (product owner), with K. Duarte (tech lead, AppSec) consulted because the change is higher-risk. C1–C4 were resolved with their policy owners. Recorded as this commit. *(Demo approval by fictional personas.)*
