# Intent: <one line, in the originator's words>

Author: <name, role>. Status: draft.
Stage: 1 Plan · Owner: <product owner> · Gate: product owner accepts into Stage 2 Design
Captured: <date> in a brainstorm with Claude; corrected by the originator before commit.

## Problem
<What happens today, with the numbers the originator knows.>

## Proposed outcome
<What changes for users when this works.>

## Affected users and systems

## Constraints
<Policy, security, cost, latency, scope limits.>

## Success looks like
<Two or three measurable signals.>

## Open questions
<Each one: who answers it, or "carried to spec".>

## Gate decision
<Accepted or rejected by the product owner, with the date and the reason.>
