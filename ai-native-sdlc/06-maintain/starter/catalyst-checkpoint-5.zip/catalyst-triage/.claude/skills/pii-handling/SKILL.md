---
name: pii-handling
description: Apply Catalyst's customer PII handling standard. Use whenever writing a spec, code, prompt, log line, test fixture or eval that touches customer messages, tickets, orders or account data.
version: 1.2.0
owner: Privacy Office (A. Lindqvist)
---
# Customer PII handling (Catalyst standard PRV-04)

PII in scope: email addresses, phone numbers, payment card numbers (PAN, any grouping), street addresses with postal codes, full date of birth.
Order numbers (CH-xxxxxxx) and first names alone are NOT PII under PRV-04.

When you design or change anything that handles customer text:
1. Redact before egress. Replace PII with typed placeholders `[EMAIL]`, `[PHONE]`, `[CARD]`, `[ADDRESS]`, `[DOB]` before the text leaves our boundary (third-party APIs, including model providers).
2. Never log raw customer text. Logs carry ticket ID, placeholders and model outputs only.
3. Generated text (summaries, notes) must not contain PII, even if the input slipped past redaction. Treat a PII leak in output as a Sev-2 defect.
4. Test fixtures and eval data use synthetic PII only, and every eval suite includes a PII-leak check that scores the output against the known PII values in each case.
5. Flag any requirement that cannot meet rules 1–3 as an area of concern, naming the Privacy Office as policy owner.
