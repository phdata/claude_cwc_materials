---
name: support-taxonomy
description: Catalyst's support ticket taxonomy, priority rubric and queue map. Use whenever classifying tickets, writing triage prompts, building routing code, or labelling eval data for Customer Care.
version: 3.1.0
owner: Customer Care operations (D. Okafor)
---
# Support taxonomy v3.1

## Categories → queue
| category | meaning | queue |
|---|---|---|
| order_status | where is my order, tracking, delivery ETA (not yet late) | fulfillment |
| shipping_problem | late past promised date, lost, damaged in transit, wrong address/item delivered | fulfillment |
| return_refund | start a return, exchange, refund status | returns |
| product_defect | product broke or malfunctions in normal use, warranty claim | warranty |
| product_safety | injury, burn, fire, smoke, gas leak, carbon monoxide, allergic reaction from a product | safety |
| billing_payment | charges, duplicate charge, promo/price adjustment, invoice, gift card | billing |
| account_privacy | login, password, account changes, data export or deletion request | account |
| product_question | pre-purchase questions: sizing, specs, stock, compatibility | sales |
| other | feedback, partnership, spam, anything else | general |

When a ticket has several issues, pick the category for the issue with the highest priority.

## Priority rubric
- P1: product safety; duplicate or unauthorised charge; threat of chargeback or legal action; suspected account takeover.
- P2: customer blocked and time-sensitive (late order needed for a dated trip/event, refund overdue >14 days, cannot log in).
- P3: standard request with no deadline.
- P4: informational, feedback, spam, general pre-sales questions.

## Escalate to a human first (needs_human = true)
product_safety; legal or chargeback threat; data deletion/export request (privacy law clock); abusive or threatening language; classifier unsure.
Routing rule: product_safety → `safety`; any other needs_human ticket → `escalations`; otherwise the category's queue.
