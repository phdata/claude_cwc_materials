#!/bin/bash
# Stage 5 approval gate (playbook "Hooks as approval gates"): the agent may act up to the production gate and cannot pass it.
cmd=$(python3 -c 'import sys,json; print(json.load(sys.stdin).get("tool_input",{}).get("command",""))')
if [[ "$cmd" == *"deploy"* && "$cmd" == *"production"* ]]; then
  if [ -z "$RELEASE_APPROVAL" ]; then
    echo "BLOCKED: production deploys need a named release authorization from the release manager (J. Whitfield). Prepare the release checklist and request approval; set RELEASE_APPROVAL=<CHG ticket> once granted." >&2
    exit 2
  fi
fi
exit 0
