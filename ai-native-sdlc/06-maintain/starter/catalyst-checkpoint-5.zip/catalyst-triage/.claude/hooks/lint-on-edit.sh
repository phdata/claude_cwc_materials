#!/bin/bash
# Fast lint on the Python file just edited, so drift never accumulates (playbook Stage 3 build-time hooks).
path=$(python3 -c 'import sys,json; print(json.load(sys.stdin).get("tool_input",{}).get("file_path",""))')
[[ "$path" == *.py ]] || exit 0
"${CLAUDE_PROJECT_DIR:-.}/.venv/bin/python" -m pyflakes "$path" >&2 || exit 2
exit 0
