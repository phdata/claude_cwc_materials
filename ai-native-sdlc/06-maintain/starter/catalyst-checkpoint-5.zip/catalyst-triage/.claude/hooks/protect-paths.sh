#!/bin/bash
# Build/Test-stage guardrail (playbook Stage 3 + Stage 4): deterministic, fast, scoped to the file being edited.
#  - evals/dataset/** holds gold labels: changes need the Care ops owner's sign-off (DATASET_CHANGE_APPROVED=<ticket>).
#  - During a fix task (TRIAGE_FIX_MODE=1) the agent may not edit tests: fix the code, not the test.
#  - No credentials in any written file.
input=$(cat)
path=$(printf '%s' "$input" | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d.get("tool_input",{}).get("file_path",""))')
content=$(printf '%s' "$input" | python3 -c 'import sys,json; t=json.load(sys.stdin).get("tool_input",{}); print(t.get("content","") + t.get("new_string",""))')

case "$path" in
  */evals/dataset/*)
    if [ -z "$DATASET_CHANGE_APPROVED" ]; then
      echo "BLOCKED: evals/dataset/ holds gold labels owned by Care ops (D. Okafor). Fix the prompt or code instead, or get sign-off and set DATASET_CHANGE_APPROVED=<ticket>." >&2
      exit 2
    fi ;;
  */app/tests/*)
    if [ "$TRIAGE_FIX_MODE" = "1" ]; then
      echo "BLOCKED: fix task in progress (TRIAGE_FIX_MODE=1). Make the existing test pass without editing it." >&2
      exit 2
    fi ;;
esac

if printf '%s' "$content" | grep -Eq 'sk-ant-[A-Za-z0-9_-]{10,}|AKIA[0-9A-Z]{16}'; then
  echo "BLOCKED: the edit contains what looks like a credential. Use environment variables." >&2
  exit 2
fi
exit 0
