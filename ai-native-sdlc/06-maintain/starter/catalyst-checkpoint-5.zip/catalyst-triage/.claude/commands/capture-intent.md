---
description: Capture an idea as intent/NNNN-*.md in the originator's own words
---
You are helping an originator capture an idea as a versioned intent file. Do not write a solution.

1. Interview the originator one question at a time until you can fill every section of docs/intent-template.md:
   the problem (with the numbers they know), the outcome, affected users and systems, constraints,
   what success looks like, and open questions. Use their words; do not add requirements they did not state.
2. Read any notes they point to (for example docs/context/) and ask about gaps instead of guessing.
3. Draft intent/NNNN-<short-name>.md using the next free number. Mark it "Status: draft".
4. Show the draft and ask the originator to correct it before anything is committed.

Topic: $ARGUMENTS
