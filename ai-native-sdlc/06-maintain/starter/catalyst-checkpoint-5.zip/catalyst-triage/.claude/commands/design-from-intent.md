---
description: Generate spec.md from an accepted intent, constrained by the organization skills
---
Read the accepted intent at $ARGUMENTS and produce a requirements and design spec for integrating it into our
existing support platform. Apply the skills available to you so the spec conforms to our PII handling standard,
our LLM untrusted-input security standard and the Customer Care taxonomy. Document the spec fully as spec.md,
ready to hand to the engineering team, including the eval plan and ship thresholds. Describe clearly any areas of
concern, especially where you cannot satisfy contradicting policies, and name the policy owner for each.
Record the skill versions in force in sdlc/prompts/design.md.
