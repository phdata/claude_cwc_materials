# Catalyst Holdings ticket triage: checkpoint 1

This repo is the starting point for Course 2 (Design) in the AI-Native SDLC course series.
Catalyst Holdings, its people, tickets and figures are fictional. All data is synthetic.

## Start here
```
make setup     # creates .venv and installs requirements
make test      # the feedback loop; healthy output is "N passed" or the no-code message
git log --oneline   # the audit trail: one commit per stage artifact
```
Then open Claude Code in this folder (`claude`) and accept the workspace trust prompt so project settings load.

## The artifact chain
| Stage | Artifact | Status |
|---|---|---|
| 1 Plan | `intent/0001-ticket-triage.md` | in this checkpoint |
| 2 Design | `spec.md, .claude/skills/` | not yet |
| 3 Build | `plan.md, CLAUDE.md, .claude/hooks/, app/` | not yet |
| 4 Test | `app/tests/, evals/` | not yet |
| 5 Deploy | `REVIEW.md, production gate, .github/workflows/ci.yml` | not yet |
| 6 Maintain | `ops/bands.yaml, intent/0002` | not yet |

Benchmark: Anthropic, "The AI-native SDLC playbook" (https://claude.com/resources/articles/the-ai-native-sdlc-playbook).
