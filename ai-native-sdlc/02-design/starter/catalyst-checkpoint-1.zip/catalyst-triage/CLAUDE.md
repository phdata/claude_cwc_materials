# Catalyst Holdings ticket triage

Fictional client. Python 3.9+. Artifact chain: `intent/` -> `spec.md` -> `plan.md` -> code -> evals -> PR.
No application code yet: Course 3 builds `app/` from `plan.md`.

## Commands
- Setup: `make setup`
- Test: `make test` (prints a no-code message until `app/` exists)

## Conventions
- One idea per file in `intent/`, numbered `NNNN-short-name.md`, written from `docs/intent-template.md`.
- Keep only intent files in `intent/`: the maintenance loop numbers new intents by counting them.
- Data in this repo is synthetic. Never paste real customer text anywhere in this repo.
