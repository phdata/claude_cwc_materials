# Intent: Ember heater recall tickets are being misrouted away from product_safety
Author: Claude (maintenance loop, ops/detect.py). Status: draft, awaiting triage by the service owner.
Stage: 1 Plan · Source: control-band breach 3sigma on agent_override_rate · Owner: S. Patel (service owner)

## Problem
The shadow-mode agent override rate hit 19.0% on 2026-10-08, against a baseline of 8.1% ± 0.5%. Both rules fired: R1 (latest point beyond 3σ) and R2 (two of the last three points beyond 2σ). The most likely cause is a new type of ticket: customer questions about the Ember heater recall. The model routes these to product_question, product_defect or return_refund. Agents move them to product_safety. The model doesn't seem to treat a recall as a safety issue, including when the ticket is in French.

## Evidence
- 183 override records from 2026-10-02 to 2026-10-08.
- 126 of 183 overrides (69%) changed the category to product_safety: product_question→product_safety 64, product_defect→product_safety 35, return_refund→product_safety 27.
- The recall-related ticket texts in the top list also add up to 126: 33 + 23 + 23 + 19 + 15 + 13. Every one mentions the Ember recall (whether a unit is covered, whether to stop using it, serial EH-22, replacement part, the 2-burner stove, refund instead).
- All 33 French overrides are a single recall question ("Est-ce que mon chauffage Ember est visé par le rappel?"). French tickets seem to fail the same way English ones do.
- The other overrides don't look related to the recall: product_defect→shipping_problem 19 (matches "Arrived with a cracked buckle", 19x), order_status→shipping_problem 15 (matches "Order is 2 days late", 15x) and return_refund→billing_payment 12. They may be part of the normal background override rate.

## Proposed outcome
- Tickets that ask about a product recall (whether a unit is covered, whether to keep using it, how to get a remedy or a refund) are routed to product_safety, in English and French.
- Possible approaches for the owner to choose from: add recall examples and wording to the classifier prompt or few-shot set, and/or add a deterministic recall flag that sends these tickets to product_safety. Both should be checked against a held-out set of recall tickets before shadow promotion.
- Measure success as an override rate back inside the band (about 8.1% ± 0.5%) and recall-related overrides near zero.
- Look at the cracked-buckle and late-order patterns separately, as possible taxonomy-boundary questions, and don't bundle them into this fix.

## Affected users and systems
- Customers asking about the Ember heater recall. Safety questions such as "Do I stop using it?" could reach a non-safety queue if this service goes beyond shadow mode.
- Support agents carrying the extra override load. The safety team's queue gets less recall volume than it should.
- The triage classifier, its prompt and few-shot set, and the ops/detect.py control band.

## Constraints
- Do not change eval gold labels. Evaluate fixes against the existing gold set plus new recall cases added separately.
- The service stays in shadow mode. Nothing ships to live routing without the owner's approval.
- The fix has to work for French as well as English.
- Avoid over-routing: product tickets that aren't about a recall should not drift into product_safety.

## Open questions
- When did the recall notice go out? Did it line up with the jump that started around 2026-10-02?
- Should "Can I return it for a refund instead?" during a recall go to product_safety or return_refund? Policy needs to decide.
- Is the Ember 2-burner stove covered by the recall? Agents routed those 15 tickets to product_safety either way.
- Without the recall tickets, are the remaining 57 overrides inside the baseline rate? The total ticket volume needed to check this isn't in the evidence.
- Should known active recalls be fed to the classifier as context (for example, a recall registry)?
