# Runbook: rollback-triage (pre-approved for the 3-sigma tier)

Owner: S. Patel (service owner). Approved by: J. Whitfield (release manager). Review every quarter.

## When Claude may run it without a person
- `ops/detect.py` reports a 3-sigma breach on agent_override_rate, AND
- the breach started within 24 hours of a prompt or taxonomy release, AND
- the previous release passed every ship threshold in spec.md section 4.

## What it does
1. Re-deploy the previous prompt version in shadow mode: `./deploy/deploy.sh production --shadow` with
   `PROMPT_VERSION=<previous>` (the production gate still requires `RELEASE_APPROVAL`; this runbook's
   standing approval is CHG-RUNBOOK-ROLLBACK-TRIAGE).
2. Post the detection log and the diff of the two prompt versions to the incident channel.
3. Open an intent with the evidence so the product owner gate decides the real fix.

## When it stays human-only
- Any breach not tied to a release, any change to routing rules or gold labels, any customer-facing message.
