# Lessons (version-controlled; read by humans and by Claude)

## 2026-10-08 · Ember heater recall tickets misrouted away from product_safety
- Detected by: ops/detect.py, 3-sigma breach on agent_override_rate (19.0% vs 8.1% baseline). No model ran before the breach.
- Diagnosed by: Claude, read-only, from ops/data/overrides_recent.csv. Draft became intent/0002.
- Triage: service owner (S. Patel) chose "fix" and sent the intent to the product owner gate.
- Lesson: a recall is a safety issue even when the ticket reads like a product question. Add recall wording, in English
  and French, to the escalation eval slice so this class of miss fails CI before it reaches production.
- Follow-up: eval cases for recall wording; taxonomy note in support-taxonomy SKILL.md (owner: Care ops).
